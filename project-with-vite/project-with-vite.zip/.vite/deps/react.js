import {
  require_react
} from "./chunk-V42YN7MM.js";
export default require_react();
//# sourceMappingURL=react.js.map
