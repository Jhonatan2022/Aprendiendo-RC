// Creamos una constante con un arreglo de tareas
export const tasks = [
    {
        id: 0,
        text: "Doctor Appointment",
        description: "Hello word",
    },
    {
        id: 1,
        text: "Meeting at School",
        description: "Goodbye word",
    },
];
